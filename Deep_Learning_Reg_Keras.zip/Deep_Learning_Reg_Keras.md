[Explication de nombre de parametres de couches dans le resultat de model.summary()](https://stackoverflow.com/questions/36946671/keras-model-summary-result-understanding-the-of-parameters)

[Le rôle de biais dans les reseau de neurones](https://stackoverflow.com/questions/2480650/what-is-the-role-of-the-bias-in-neural-networks)

# **Les données**
Nous utiliserons des données provenant d'un ensemble de données Kaggle :

https://www.kaggle.com/harlfoxem/housesalesprediction

Colonnes Features (caractéristiques)

- **id** - ID unique pour chaque maison vendue

- **date** - Date de la vente de la maison

- **price** - Prix de chaque maison vendue

- **bedrooms** - Nombre de chambres

- **bathrooms** - Nombre de salles de bains, où 0,5 correspond à une chambre avec toilettes mais sans douche

- **sqft_living** - Superficie habitable

- **sqft_lot** - Superficie du terrain

- **floors** - Nombre d'étages

- **waterfront** - Une variable dummy (fictive) indiquant si l'appartement donnait sur le front de mer ou non

- **view** - Un indice de 0 à 4 de la qualité de la vue de la propriété
condition - Un indice de 1 à 5 sur l'état de l'appartement

- **grade** - Un indice de 1 à 13, où 1-3 a un niveau de qualité faible de construction et de conception des bâtiments, 7 a un niveau moyen de construction et de conception, et 11-13 a un niveau de qualité élevé de construction et de conception

- **sqft_above** - La superficie de l'espace intérieur du logement qui est au-dessus du niveau du sol

- **sqft_basement** - La superficie de l'espace intérieur du logement qui se trouve sous le niveau du sol

- **yr_built** - L'année où la maison a été initialement construite

- **yr_renovated** - L'année de la dernière rénovation de la maison

- **zipcode** - Dans quelle zone de code postal se trouve la maison

- **lat** - Latitude

- **long** - Longitude

- **sqft_living15** - La superficie de l'espace intérieur de l'habitation pour les 15 voisins les plus proches

- **sqft_lot15** - La superficie du terrains des 15 voisins les plus proches

**Importer les librairies necessaires**


```python
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```

**Importer le fichier csv**

Cet ensemble de données contient les prix de vente des maisons pour le comté de King, qui comprend Seattle. Il comprend les maisons vendues entre mai 2014 et mai 2015.

C'est un excellent ensemble de données pour évaluer des modèles de régression simples.


```python
df=pd.read_csv("kc_house_data.csv")
```

# **Analyse Exploratrice des données**

---


Premierement, essayons de voir si nous avons des données manquantes








```python
df.isnull().sum()
```




    id               0
    date             0
    price            0
    bedrooms         0
    bathrooms        0
    sqft_living      0
    sqft_lot         0
    floors           0
    waterfront       0
    view             0
    condition        0
    grade            0
    sqft_above       0
    sqft_basement    0
    yr_built         0
    yr_renovated     0
    zipcode          0
    lat              0
    long             0
    sqft_living15    0
    sqft_lot15       0
    dtype: int64



**Afficher la tete**


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>...</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7129300520</td>
      <td>20141013T000000</td>
      <td>221900.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1180</td>
      <td>5650</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>1180</td>
      <td>0</td>
      <td>1955</td>
      <td>0</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340</td>
      <td>5650</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6414100192</td>
      <td>20141209T000000</td>
      <td>538000.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>2570</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>2170</td>
      <td>400</td>
      <td>1951</td>
      <td>1991</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690</td>
      <td>7639</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5631500400</td>
      <td>20150225T000000</td>
      <td>180000.0</td>
      <td>2</td>
      <td>1.00</td>
      <td>770</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>6</td>
      <td>770</td>
      <td>0</td>
      <td>1933</td>
      <td>0</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720</td>
      <td>8062</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2487200875</td>
      <td>20141209T000000</td>
      <td>604000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>1960</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>1050</td>
      <td>910</td>
      <td>1965</td>
      <td>0</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1954400510</td>
      <td>20150218T000000</td>
      <td>510000.0</td>
      <td>3</td>
      <td>2.00</td>
      <td>1680</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>8</td>
      <td>1680</td>
      <td>0</td>
      <td>1987</td>
      <td>0</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800</td>
      <td>7503</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>



**Quelques statistiques descriptives**


```python
df.describe().transpose()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>id</th>
      <td>21613.0</td>
      <td>4.580302e+09</td>
      <td>2.876566e+09</td>
      <td>1.000102e+06</td>
      <td>2.123049e+09</td>
      <td>3.904930e+09</td>
      <td>7.308900e+09</td>
      <td>9.900000e+09</td>
    </tr>
    <tr>
      <th>price</th>
      <td>21613.0</td>
      <td>5.400881e+05</td>
      <td>3.671272e+05</td>
      <td>7.500000e+04</td>
      <td>3.219500e+05</td>
      <td>4.500000e+05</td>
      <td>6.450000e+05</td>
      <td>7.700000e+06</td>
    </tr>
    <tr>
      <th>bedrooms</th>
      <td>21613.0</td>
      <td>3.370842e+00</td>
      <td>9.300618e-01</td>
      <td>0.000000e+00</td>
      <td>3.000000e+00</td>
      <td>3.000000e+00</td>
      <td>4.000000e+00</td>
      <td>3.300000e+01</td>
    </tr>
    <tr>
      <th>bathrooms</th>
      <td>21613.0</td>
      <td>2.114757e+00</td>
      <td>7.701632e-01</td>
      <td>0.000000e+00</td>
      <td>1.750000e+00</td>
      <td>2.250000e+00</td>
      <td>2.500000e+00</td>
      <td>8.000000e+00</td>
    </tr>
    <tr>
      <th>sqft_living</th>
      <td>21613.0</td>
      <td>2.079900e+03</td>
      <td>9.184409e+02</td>
      <td>2.900000e+02</td>
      <td>1.427000e+03</td>
      <td>1.910000e+03</td>
      <td>2.550000e+03</td>
      <td>1.354000e+04</td>
    </tr>
    <tr>
      <th>sqft_lot</th>
      <td>21613.0</td>
      <td>1.510697e+04</td>
      <td>4.142051e+04</td>
      <td>5.200000e+02</td>
      <td>5.040000e+03</td>
      <td>7.618000e+03</td>
      <td>1.068800e+04</td>
      <td>1.651359e+06</td>
    </tr>
    <tr>
      <th>floors</th>
      <td>21613.0</td>
      <td>1.494309e+00</td>
      <td>5.399889e-01</td>
      <td>1.000000e+00</td>
      <td>1.000000e+00</td>
      <td>1.500000e+00</td>
      <td>2.000000e+00</td>
      <td>3.500000e+00</td>
    </tr>
    <tr>
      <th>waterfront</th>
      <td>21613.0</td>
      <td>7.541757e-03</td>
      <td>8.651720e-02</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>1.000000e+00</td>
    </tr>
    <tr>
      <th>view</th>
      <td>21613.0</td>
      <td>2.343034e-01</td>
      <td>7.663176e-01</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>4.000000e+00</td>
    </tr>
    <tr>
      <th>condition</th>
      <td>21613.0</td>
      <td>3.409430e+00</td>
      <td>6.507430e-01</td>
      <td>1.000000e+00</td>
      <td>3.000000e+00</td>
      <td>3.000000e+00</td>
      <td>4.000000e+00</td>
      <td>5.000000e+00</td>
    </tr>
    <tr>
      <th>grade</th>
      <td>21613.0</td>
      <td>7.656873e+00</td>
      <td>1.175459e+00</td>
      <td>1.000000e+00</td>
      <td>7.000000e+00</td>
      <td>7.000000e+00</td>
      <td>8.000000e+00</td>
      <td>1.300000e+01</td>
    </tr>
    <tr>
      <th>sqft_above</th>
      <td>21613.0</td>
      <td>1.788391e+03</td>
      <td>8.280910e+02</td>
      <td>2.900000e+02</td>
      <td>1.190000e+03</td>
      <td>1.560000e+03</td>
      <td>2.210000e+03</td>
      <td>9.410000e+03</td>
    </tr>
    <tr>
      <th>sqft_basement</th>
      <td>21613.0</td>
      <td>2.915090e+02</td>
      <td>4.425750e+02</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>5.600000e+02</td>
      <td>4.820000e+03</td>
    </tr>
    <tr>
      <th>yr_built</th>
      <td>21613.0</td>
      <td>1.971005e+03</td>
      <td>2.937341e+01</td>
      <td>1.900000e+03</td>
      <td>1.951000e+03</td>
      <td>1.975000e+03</td>
      <td>1.997000e+03</td>
      <td>2.015000e+03</td>
    </tr>
    <tr>
      <th>yr_renovated</th>
      <td>21613.0</td>
      <td>8.440226e+01</td>
      <td>4.016792e+02</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>2.015000e+03</td>
    </tr>
    <tr>
      <th>zipcode</th>
      <td>21613.0</td>
      <td>9.807794e+04</td>
      <td>5.350503e+01</td>
      <td>9.800100e+04</td>
      <td>9.803300e+04</td>
      <td>9.806500e+04</td>
      <td>9.811800e+04</td>
      <td>9.819900e+04</td>
    </tr>
    <tr>
      <th>lat</th>
      <td>21613.0</td>
      <td>4.756005e+01</td>
      <td>1.385637e-01</td>
      <td>4.715590e+01</td>
      <td>4.747100e+01</td>
      <td>4.757180e+01</td>
      <td>4.767800e+01</td>
      <td>4.777760e+01</td>
    </tr>
    <tr>
      <th>long</th>
      <td>21613.0</td>
      <td>-1.222139e+02</td>
      <td>1.408283e-01</td>
      <td>-1.225190e+02</td>
      <td>-1.223280e+02</td>
      <td>-1.222300e+02</td>
      <td>-1.221250e+02</td>
      <td>-1.213150e+02</td>
    </tr>
    <tr>
      <th>sqft_living15</th>
      <td>21613.0</td>
      <td>1.986552e+03</td>
      <td>6.853913e+02</td>
      <td>3.990000e+02</td>
      <td>1.490000e+03</td>
      <td>1.840000e+03</td>
      <td>2.360000e+03</td>
      <td>6.210000e+03</td>
    </tr>
    <tr>
      <th>sqft_lot15</th>
      <td>21613.0</td>
      <td>1.276846e+04</td>
      <td>2.730418e+04</td>
      <td>6.510000e+02</td>
      <td>5.100000e+03</td>
      <td>7.620000e+03</td>
      <td>1.008300e+04</td>
      <td>8.712000e+05</td>
    </tr>
  </tbody>
</table>
</div>



**Nous allons maintenant explorer un peu ces données en utilisant quelques techniques de visualistation de données.**

On remarque que la plus part de nos maisons tombent entre 0 et 1 millions de dollars et on peut avoir quelques valeurs extrêmes pour nos maisons vraiment très cheres. Il peut être bien de supprimer ces prix extrêmes de notre analyse, si elles ne representent qu'un faible nombre des points de données. Donc, on peut construire un modéle qui prédit de façon réaliste les prix de maisons pour des valeurs comprises entre 0 et 2 millions de dolllars. Si on supprime les prix extrêmes cela ne representra pas beaucoup des maoisons appparement sur le marché, les maisons valant plus de 3 millions de dollars sont toutes même assez rares. Si on veut construire un model pour une Agence Immobili2re. 


```python
plt.figure(figsize=(10, 6))
sns.distplot(df["price"])
```

    C:\Users\HP\anaconda3\envs\pyfinance\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    




    <AxesSubplot:xlabel='price', ylabel='Density'>




    
![png](output_13_2.png)
    


**Afficher le nombre de chambres**

La majorité de maisons sont entre deux et cinq chambres. Il y a peut être une seule maison qui posede 33 chambres. C'est pourquoi la valeur apparait sur l'axe x mais cela ne montre pas de bare. 


```python
sns.countplot(df["bedrooms"])
```

    C:\Users\HP\anaconda3\envs\pyfinance\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='bedrooms', ylabel='count'>




    
![png](output_15_2.png)
    


**Corrélation**

Constatons la corrélation. Et ensuite on peut voir ce qui est fortement correlé avec notre label (price) et nous trions par la suite avec sort_values pour voir ce qui est fortement correlé avec notre label. La surface habitable (sqft_living) semble trés corrélée avec les prix réels de maisons. Il faut alors exporer les varaibles très fortement corrélées avec notre label avec un graphique à nuage de points ou scaterplot



```python
df.corr()["price"].sort_values()
```




    zipcode         -0.053203
    id              -0.016762
    long             0.021626
    condition        0.036362
    yr_built         0.054012
    sqft_lot15       0.082447
    sqft_lot         0.089661
    yr_renovated     0.126434
    floors           0.256794
    waterfront       0.266369
    lat              0.307003
    bedrooms         0.308350
    sqft_basement    0.323816
    view             0.397293
    bathrooms        0.525138
    sqft_living15    0.585379
    sqft_above       0.605567
    grade            0.667434
    sqft_living      0.702035
    price            1.000000
    Name: price, dtype: float64



**Faites un nuage de points**


```python
plt.figure(figsize=(10, 5))
sns.scatterplot(x='price', y='sqft_living', data=df)
```




    <AxesSubplot:xlabel='price', ylabel='sqft_living'>




    
![png](output_19_1.png)
    


**Boxplot**

Boxplot de la distribution de prix par nombre de chambres. Il y a une grande variation entre 3 et 7 chambres. Et c'est ce qui correspond à notre graphique de comptage. Cela explique donc pourquoi il y a une grande variation dans les prix entre 3 et 7 chambres


```python
plt.figure(figsize=(10,5))
sns.boxenplot(x="bedrooms", y="price", data=df)
```




    <AxesSubplot:xlabel='bedrooms', ylabel='price'>




    
![png](output_21_1.png)
    


Il semble avoir une distribution de prix pour la longititude -122.2. Cela semble donc à une zone de maison qui coûte assez chère. On peut voir très clairement la distribution tout long du prix 


```python
plt.figure(figsize=(10,5))
sns.scatterplot(x="price", y="long", data=df)
```




    <AxesSubplot:xlabel='price', ylabel='long'>




    
![png](output_23_1.png)
    


Le même comprtement que précédement semble se produire, il y a une zone de maisons assez chères


```python
plt.figure(figsize=(10,5))
sns.scatterplot(x="price", y="lat", data=df)
```




    <AxesSubplot:xlabel='price', ylabel='lat'>




    
![png](output_25_1.png)
    


Cela colore de plus ou moins foncée en fonction de prix. Très claire si le prix est faible et très focné si le prix est elevé. Et on remarque une zone plus foncée qui semble correspondre à la longititude de -122.2 et latitude entre 47.6 et 47.7. On va nettoyer cette carte en retirant les valeurs extrêmes et donc les prix très élevés. 


```python
plt.figure(figsize=(10,5))
sns.scatterplot(x="long", y="lat", data=df, hue="price")
```




    <AxesSubplot:xlabel='long', ylabel='lat'>




    
![png](output_27_1.png)
    


Trier sur la variable price et regarder les 20 maisons les plus chères 


```python
df.sort_values("price", ascending=False).head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>...</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7252</th>
      <td>6762700020</td>
      <td>20141013T000000</td>
      <td>7700000.0</td>
      <td>6</td>
      <td>8.00</td>
      <td>12050</td>
      <td>27600</td>
      <td>2.5</td>
      <td>0</td>
      <td>3</td>
      <td>...</td>
      <td>13</td>
      <td>8570</td>
      <td>3480</td>
      <td>1910</td>
      <td>1987</td>
      <td>98102</td>
      <td>47.6298</td>
      <td>-122.323</td>
      <td>3940</td>
      <td>8800</td>
    </tr>
    <tr>
      <th>3914</th>
      <td>9808700762</td>
      <td>20140611T000000</td>
      <td>7062500.0</td>
      <td>5</td>
      <td>4.50</td>
      <td>10040</td>
      <td>37325</td>
      <td>2.0</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>11</td>
      <td>7680</td>
      <td>2360</td>
      <td>1940</td>
      <td>2001</td>
      <td>98004</td>
      <td>47.6500</td>
      <td>-122.214</td>
      <td>3930</td>
      <td>25449</td>
    </tr>
    <tr>
      <th>9254</th>
      <td>9208900037</td>
      <td>20140919T000000</td>
      <td>6885000.0</td>
      <td>6</td>
      <td>7.75</td>
      <td>9890</td>
      <td>31374</td>
      <td>2.0</td>
      <td>0</td>
      <td>4</td>
      <td>...</td>
      <td>13</td>
      <td>8860</td>
      <td>1030</td>
      <td>2001</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6305</td>
      <td>-122.240</td>
      <td>4540</td>
      <td>42730</td>
    </tr>
    <tr>
      <th>4411</th>
      <td>2470100110</td>
      <td>20140804T000000</td>
      <td>5570000.0</td>
      <td>5</td>
      <td>5.75</td>
      <td>9200</td>
      <td>35069</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>13</td>
      <td>6200</td>
      <td>3000</td>
      <td>2001</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6289</td>
      <td>-122.233</td>
      <td>3560</td>
      <td>24345</td>
    </tr>
    <tr>
      <th>1448</th>
      <td>8907500070</td>
      <td>20150413T000000</td>
      <td>5350000.0</td>
      <td>5</td>
      <td>5.00</td>
      <td>8000</td>
      <td>23985</td>
      <td>2.0</td>
      <td>0</td>
      <td>4</td>
      <td>...</td>
      <td>12</td>
      <td>6720</td>
      <td>1280</td>
      <td>2009</td>
      <td>0</td>
      <td>98004</td>
      <td>47.6232</td>
      <td>-122.220</td>
      <td>4600</td>
      <td>21750</td>
    </tr>
    <tr>
      <th>1315</th>
      <td>7558700030</td>
      <td>20150413T000000</td>
      <td>5300000.0</td>
      <td>6</td>
      <td>6.00</td>
      <td>7390</td>
      <td>24829</td>
      <td>2.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>12</td>
      <td>5000</td>
      <td>2390</td>
      <td>1991</td>
      <td>0</td>
      <td>98040</td>
      <td>47.5631</td>
      <td>-122.210</td>
      <td>4320</td>
      <td>24619</td>
    </tr>
    <tr>
      <th>1164</th>
      <td>1247600105</td>
      <td>20141020T000000</td>
      <td>5110800.0</td>
      <td>5</td>
      <td>5.25</td>
      <td>8010</td>
      <td>45517</td>
      <td>2.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>12</td>
      <td>5990</td>
      <td>2020</td>
      <td>1999</td>
      <td>0</td>
      <td>98033</td>
      <td>47.6767</td>
      <td>-122.211</td>
      <td>3430</td>
      <td>26788</td>
    </tr>
    <tr>
      <th>8092</th>
      <td>1924059029</td>
      <td>20140617T000000</td>
      <td>4668000.0</td>
      <td>5</td>
      <td>6.75</td>
      <td>9640</td>
      <td>13068</td>
      <td>1.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>12</td>
      <td>4820</td>
      <td>4820</td>
      <td>1983</td>
      <td>2009</td>
      <td>98040</td>
      <td>47.5570</td>
      <td>-122.210</td>
      <td>3270</td>
      <td>10454</td>
    </tr>
    <tr>
      <th>2626</th>
      <td>7738500731</td>
      <td>20140815T000000</td>
      <td>4500000.0</td>
      <td>5</td>
      <td>5.50</td>
      <td>6640</td>
      <td>40014</td>
      <td>2.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>12</td>
      <td>6350</td>
      <td>290</td>
      <td>2004</td>
      <td>0</td>
      <td>98155</td>
      <td>47.7493</td>
      <td>-122.280</td>
      <td>3030</td>
      <td>23408</td>
    </tr>
    <tr>
      <th>8638</th>
      <td>3835500195</td>
      <td>20140618T000000</td>
      <td>4489000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>6430</td>
      <td>27517</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>12</td>
      <td>6430</td>
      <td>0</td>
      <td>2001</td>
      <td>0</td>
      <td>98004</td>
      <td>47.6208</td>
      <td>-122.219</td>
      <td>3720</td>
      <td>14592</td>
    </tr>
    <tr>
      <th>12370</th>
      <td>6065300370</td>
      <td>20150506T000000</td>
      <td>4208000.0</td>
      <td>5</td>
      <td>6.00</td>
      <td>7440</td>
      <td>21540</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>12</td>
      <td>5550</td>
      <td>1890</td>
      <td>2003</td>
      <td>0</td>
      <td>98006</td>
      <td>47.5692</td>
      <td>-122.189</td>
      <td>4740</td>
      <td>19329</td>
    </tr>
    <tr>
      <th>4149</th>
      <td>6447300265</td>
      <td>20141014T000000</td>
      <td>4000000.0</td>
      <td>4</td>
      <td>5.50</td>
      <td>7080</td>
      <td>16573</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>12</td>
      <td>5760</td>
      <td>1320</td>
      <td>2008</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6151</td>
      <td>-122.224</td>
      <td>3140</td>
      <td>15996</td>
    </tr>
    <tr>
      <th>2085</th>
      <td>8106100105</td>
      <td>20141114T000000</td>
      <td>3850000.0</td>
      <td>4</td>
      <td>4.25</td>
      <td>5770</td>
      <td>21300</td>
      <td>2.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>11</td>
      <td>5770</td>
      <td>0</td>
      <td>1980</td>
      <td>0</td>
      <td>98040</td>
      <td>47.5850</td>
      <td>-122.222</td>
      <td>4620</td>
      <td>22748</td>
    </tr>
    <tr>
      <th>19017</th>
      <td>2303900100</td>
      <td>20140911T000000</td>
      <td>3800000.0</td>
      <td>3</td>
      <td>4.25</td>
      <td>5510</td>
      <td>35000</td>
      <td>2.0</td>
      <td>0</td>
      <td>4</td>
      <td>...</td>
      <td>13</td>
      <td>4910</td>
      <td>600</td>
      <td>1997</td>
      <td>0</td>
      <td>98177</td>
      <td>47.7296</td>
      <td>-122.370</td>
      <td>3430</td>
      <td>45302</td>
    </tr>
    <tr>
      <th>7035</th>
      <td>853200010</td>
      <td>20140701T000000</td>
      <td>3800000.0</td>
      <td>5</td>
      <td>5.50</td>
      <td>7050</td>
      <td>42840</td>
      <td>1.0</td>
      <td>0</td>
      <td>2</td>
      <td>...</td>
      <td>13</td>
      <td>4320</td>
      <td>2730</td>
      <td>1978</td>
      <td>0</td>
      <td>98004</td>
      <td>47.6229</td>
      <td>-122.220</td>
      <td>5070</td>
      <td>20570</td>
    </tr>
    <tr>
      <th>16302</th>
      <td>7397300170</td>
      <td>20140530T000000</td>
      <td>3710000.0</td>
      <td>4</td>
      <td>3.50</td>
      <td>5550</td>
      <td>28078</td>
      <td>2.0</td>
      <td>0</td>
      <td>2</td>
      <td>...</td>
      <td>12</td>
      <td>3350</td>
      <td>2200</td>
      <td>2000</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6395</td>
      <td>-122.234</td>
      <td>2980</td>
      <td>19602</td>
    </tr>
    <tr>
      <th>6508</th>
      <td>4217402115</td>
      <td>20150421T000000</td>
      <td>3650000.0</td>
      <td>6</td>
      <td>4.75</td>
      <td>5480</td>
      <td>19401</td>
      <td>1.5</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>11</td>
      <td>3910</td>
      <td>1570</td>
      <td>1936</td>
      <td>0</td>
      <td>98105</td>
      <td>47.6515</td>
      <td>-122.277</td>
      <td>3510</td>
      <td>15810</td>
    </tr>
    <tr>
      <th>18482</th>
      <td>4389201095</td>
      <td>20150511T000000</td>
      <td>3650000.0</td>
      <td>5</td>
      <td>3.75</td>
      <td>5020</td>
      <td>8694</td>
      <td>2.0</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>12</td>
      <td>3970</td>
      <td>1050</td>
      <td>2007</td>
      <td>0</td>
      <td>98004</td>
      <td>47.6146</td>
      <td>-122.213</td>
      <td>4190</td>
      <td>11275</td>
    </tr>
    <tr>
      <th>15255</th>
      <td>2425049063</td>
      <td>20140911T000000</td>
      <td>3640900.0</td>
      <td>4</td>
      <td>3.25</td>
      <td>4830</td>
      <td>22257</td>
      <td>2.0</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>11</td>
      <td>4830</td>
      <td>0</td>
      <td>1990</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6409</td>
      <td>-122.241</td>
      <td>3820</td>
      <td>25582</td>
    </tr>
    <tr>
      <th>19148</th>
      <td>3625049042</td>
      <td>20141011T000000</td>
      <td>3635000.0</td>
      <td>5</td>
      <td>6.00</td>
      <td>5490</td>
      <td>19897</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>12</td>
      <td>5490</td>
      <td>0</td>
      <td>2005</td>
      <td>0</td>
      <td>98039</td>
      <td>47.6165</td>
      <td>-122.236</td>
      <td>2910</td>
      <td>17600</td>
    </tr>
  </tbody>
</table>
<p>20 rows × 21 columns</p>
</div>




```python
non_top_1_perc=df.sort_values("price", ascending=False).iloc[216:]
```

Maintenant la distribution de couleurs est nettement visible. L'objectif c'est de rendre beaucoup plus claire, l'emplacement des maisons chàres. La zone de maisons un peu plus chères, c'est autour des couleurs jaune, rouge et vert et tout autour de cette zone, on a des prix plus bas. D'ailleurs les zones assez chères sont rassemblées autour des points d'eau. Ce qui a du sens puisqu'une proprieté avec un accés au point d'eau ou avec vue sur mer et plus chère qu'une proprieté dans les terres. On a consideré 99% des maisons en excluant le top 1% des demeures les plus chères.


```python
plt.figure(figsize=(10,5))
sns.scatterplot(x="long", y="lat", data=non_top_1_perc, hue="price", edgecolor=None, alpha=0.2, palette="RdYlGn")
```




    <AxesSubplot:xlabel='long', ylabel='lat'>




    
![png](output_32_1.png)
    


On peut voir la distribution des prix si oui ou non la maison est en bord de mer ou d'un point d'eau. Et donc, clairement, il semble que si vous êtes en bord de mer donc la valeur de classe 1, vous êtes plus susceptible d'être vendue à un prix plus important et ce qui est assez logique en fait. 


```python
plt.figure(figsize=(10,5))
sns.boxenplot(x="waterfront", y="price", data=df)
```




    <AxesSubplot:xlabel='waterfront', ylabel='price'>




    
![png](output_34_1.png)
    


## ***Etape de feature engenering ou ingenerie des caracteristiques***

Cette étape permet de se débrasser des caractéristiques qui ne sont pas utiles à la construction du modéle ou encore permet de créer de nouvelles caractéristiques qui seront utiles. 

Supprimons la variable id 


```python
df=df.drop("id", axis=1)
```

Regardons la colone date. Cela ressemble à une chaine de caractère. Donc, on peut la convertir en objet de type datetime


```python
df["date"]=pd.to_datetime(df["date"])
```


```python
df["date"]
```




    0       2014-10-13
    1       2014-12-09
    2       2015-02-25
    3       2014-12-09
    4       2015-02-18
               ...    
    21608   2014-05-21
    21609   2015-02-23
    21610   2014-06-23
    21611   2015-01-16
    21612   2014-10-15
    Name: date, Length: 21613, dtype: datetime64[ns]



L'option lambda c'est un racourci pour une fonction, ça évite de la définir et d'utiliser de la memoire pour sa définition, mais c'est l'equivlent de ce qui suit : 

*df year_extraction(date)
return date.year*


```python
df["year"]=df["date"].apply(lambda date:date.year)
```


```python
df["month"]=df["date"].apply(lambda date:date.month)
```


```python
plt.figure(figsize=(10,5))
sns.boxenplot(x="month", y="price", data=df)
```




    <AxesSubplot:xlabel='month', ylabel='price'>




    
![png](output_43_1.png)
    


C'est compliquer à partir de ce graphique de dire si oui ou non il y a de différence significative dans la distribution entre les différents moi où vous allez vendre votre maison. Dans ce cas c'est peut être plus parlant de voir le nombre. Pour cela, on va taper à la suite 

Nous avons groupé par mois puis on a pris la moyenne et on explore les prix. Et là on peut voir s'il y a des différences significatives entre les mois pour l'observer visulement, on peut aussi utiliser plot sur le groupby. Et donc, cela nous montre le comprtement, il semble donc y avoir des différences entre les mois, cela va de 510000 dollars à 560000 dollars en moyenne. Donc, pas une énorme différence dans le prix mais il semble tout même que y a une tendance en fonction de mois de ventes. On peut faire la même chose pour l'année. 


```python
df.groupby("month").mean()["price"].plot()
```




    <AxesSubplot:xlabel='month'>




    
![png](output_46_1.png)
    


Là c'est très logique parce que dans cette région les prix augmentent au fur et en mesure que les années passent. Cela s'explique notmment par l'inflation naturelle de l'immoblier. Donc, on a fait du feature engenering ce qui a abouti à la création de deux nouvlles caractéristiques l'année et le mois 


```python
df.groupby("year").mean()["price"].plot()
```




    <AxesSubplot:xlabel='year'>




    
![png](output_48_1.png)
    


On supprime maintenant la variable date, elle n'est plus utile parce qu'on a extrait d'elle le mois et l'année


```python
df=df.drop("date", axis=1)
```

On va avoir une idée sur le nombre de zipcodes uniques et de leur distribution des valeurs dans le dataset. Il semble donc, on a 70 codes uniques. Et c'est probabmlement trop pour créer des variables demmies à partir de cette caractéristique. On va alors supprimer cette colonne qui peut avoir 7o demmies.


```python
df["zipcode"].value_counts()
```




    98103    602
    98038    590
    98115    583
    98052    574
    98117    553
            ... 
    98102    105
    98010    100
    98024     81
    98148     57
    98039     50
    Name: zipcode, Length: 70, dtype: int64




```python
df=df.drop("zipcode", axis=1)
```

Regardons maintenant la variable yr_renovated. On constate que la plus part de valeurs de cette variable sont de zéros signifiant simplement que la masion n'a jamais été renovée. Par ailleurs, plus la rénovation de maisons est recente mieux c'est


```python
df["yr_renovated"].value_counts()
```




    0       20699
    2014       91
    2013       37
    2003       36
    2005       35
            ...  
    1951        1
    1959        1
    1948        1
    1954        1
    1944        1
    Name: yr_renovated, Length: 70, dtype: int64



En regardant la variable correspondant à la superficie de l'interieur sous le niveauOn a du sol. En gros ce sont les sous sols non habitables. Les zeros pour une majorité d'entrée signifie qu'il n'y a pas de sous sols

## ***Etape de pre-traitement et de création de notre model***

Mettre les données à l'échelle, diviser les données en un set d'entrainement et en un set de test de construire notre modéle. Si on ajoute 'value' cela retourne en sortie ci-dessous de tableaux numpy

Separer nos caracteristiques de nos labels 


```python
X=df.drop("price", axis=1).values
y=df["price"].values
```

**Faisons maintenant la repartition entre entrainement et test**


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=101)
```


```python
y_train.shape
```




    (15129,)



On vient de faire la répartition des données. maintenant, il est temps d'éffectuer la mise en échelle ou le skling. On fait le skling après avoir fait la répartion entrainement et en test de nos données. Parce que la mise en échelle sera adaptée à nos données d'entrainment seulement pour eviter toute fuite de données depuis le set de test


```python
from sklearn.preprocessing import MinMaxScaler
```


```python
scaler=MinMaxScaler()
```

On va gagner du temps en adaptant et en transformant tout notre set d'entrainement en une seule étape avec la méthode suivante :


```python
X_train=scaler.fit_transform(X_train)
```


```python
X_test=scaler.transform(X_test)
```

**Etape de construction du model**


```python
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
```

On va essayer d'accorder les nombres de neuronnes ou units dans notre couche à partir de la taille de données X des caracteristiques. Pour cela on va regarder la forme de nos données X. Et on constate qu'on a 19 caractéristiques d'entrée et donc, c'est sans doute c'est sans doute une bonne chose, d'avoir 19 neuronnes dans notre couche.


```python
X_train.shape
```




    (15129, 19)




```python
Model = Sequential()

Model.add(Dense(19, activation='relu'))
Model.add(Dense(19, activation='relu'))
Model.add(Dense(19, activation='relu'))
Model.add(Dense(19, activation='relu'))

Model.add(Dense(1))

Model.compile(optimizer="adam", loss="mse")
```

On va éxecuter l'entrainement. Ici, on entraine sur X_train et sur y_train et aucour de cet entrainement, on vérifie ou on contrôle sur notre set de test avec ce paramétre validation_data, et cela nous donnera de supers graphiques pour savoir si oui ou non on a un overfiting. Donc, nous allons nourir ou alimenter nos données par batch des données d'entrainement ou par lot de données. Pour cela on appelle à la suite batch_zise. C'est plus frequent de prendre de puissance de 2 pour la taille du batch (64, 128, 256, etc). Et plus la taille du bacht est petit, plus lourd sera l'entrainement mais vous serez moins susceptible de surapprendre ou d'avoir de l'overfiting parce que nous ne passons pas tout notre ensemble des données en une fois 


```python
Model.fit(x=X_train, y=y_train, validation_data=(X_test, y_test), batch_size=128, epochs=400)
```

    Epoch 1/400
    119/119 [==============================] - 3s 14ms/step - loss: 423629389824.0000 - val_loss: 433029775360.0000
    Epoch 2/400
    119/119 [==============================] - 1s 7ms/step - loss: 422658146304.0000 - val_loss: 429427752960.0000
    Epoch 3/400
    119/119 [==============================] - 1s 5ms/step - loss: 407528505344.0000 - val_loss: 393394028544.0000
    Epoch 4/400
    119/119 [==============================] - 1s 5ms/step - loss: 331300864000.0000 - val_loss: 267739381760.0000
    Epoch 5/400
    119/119 [==============================] - 1s 5ms/step - loss: 181664792576.0000 - val_loss: 125727186944.0000
    Epoch 6/400
    119/119 [==============================] - 1s 5ms/step - loss: 103700758528.0000 - val_loss: 103762681856.0000
    Epoch 7/400
    119/119 [==============================] - 1s 4ms/step - loss: 97633312768.0000 - val_loss: 101999370240.0000
    Epoch 8/400
    119/119 [==============================] - 0s 4ms/step - loss: 96200826880.0000 - val_loss: 100478820352.0000
    Epoch 9/400
    119/119 [==============================] - 1s 5ms/step - loss: 94721589248.0000 - val_loss: 98807775232.0000
    Epoch 10/400
    119/119 [==============================] - 1s 4ms/step - loss: 93209559040.0000 - val_loss: 97217323008.0000
    Epoch 11/400
    119/119 [==============================] - 0s 4ms/step - loss: 91651629056.0000 - val_loss: 95408635904.0000
    Epoch 12/400
    119/119 [==============================] - 0s 4ms/step - loss: 90012213248.0000 - val_loss: 93688717312.0000
    Epoch 13/400
    119/119 [==============================] - 1s 5ms/step - loss: 88370601984.0000 - val_loss: 91787386880.0000
    Epoch 14/400
    119/119 [==============================] - 1s 4ms/step - loss: 86608494592.0000 - val_loss: 89921945600.0000
    Epoch 15/400
    119/119 [==============================] - 0s 4ms/step - loss: 84790919168.0000 - val_loss: 87918264320.0000
    Epoch 16/400
    119/119 [==============================] - 1s 4ms/step - loss: 82898968576.0000 - val_loss: 85721784320.0000
    Epoch 17/400
    119/119 [==============================] - 1s 5ms/step - loss: 80896729088.0000 - val_loss: 83520028672.0000
    Epoch 18/400
    119/119 [==============================] - 1s 5ms/step - loss: 78804992000.0000 - val_loss: 81170653184.0000
    Epoch 19/400
    119/119 [==============================] - 1s 4ms/step - loss: 76617613312.0000 - val_loss: 78748966912.0000
    Epoch 20/400
    119/119 [==============================] - 1s 5ms/step - loss: 74362961920.0000 - val_loss: 76285820928.0000
    Epoch 21/400
    119/119 [==============================] - 1s 5ms/step - loss: 72065114112.0000 - val_loss: 73723322368.0000
    Epoch 22/400
    119/119 [==============================] - 1s 6ms/step - loss: 69686853632.0000 - val_loss: 71111278592.0000
    Epoch 23/400
    119/119 [==============================] - 1s 5ms/step - loss: 67304849408.0000 - val_loss: 68608540672.0000
    Epoch 24/400
    119/119 [==============================] - 1s 4ms/step - loss: 64945557504.0000 - val_loss: 65902940160.0000
    Epoch 25/400
    119/119 [==============================] - 0s 4ms/step - loss: 62684852224.0000 - val_loss: 63438745600.0000
    Epoch 26/400
    119/119 [==============================] - 0s 4ms/step - loss: 60558249984.0000 - val_loss: 61192011776.0000
    Epoch 27/400
    119/119 [==============================] - 0s 4ms/step - loss: 58620362752.0000 - val_loss: 59041562624.0000
    Epoch 28/400
    119/119 [==============================] - 0s 4ms/step - loss: 56917508096.0000 - val_loss: 57300951040.0000
    Epoch 29/400
    119/119 [==============================] - 0s 4ms/step - loss: 55464030208.0000 - val_loss: 55805816832.0000
    Epoch 30/400
    119/119 [==============================] - 0s 4ms/step - loss: 54350381056.0000 - val_loss: 54595244032.0000
    Epoch 31/400
    119/119 [==============================] - 0s 4ms/step - loss: 53333852160.0000 - val_loss: 53566447616.0000
    Epoch 32/400
    119/119 [==============================] - 0s 4ms/step - loss: 52491386880.0000 - val_loss: 52709158912.0000
    Epoch 33/400
    119/119 [==============================] - 0s 4ms/step - loss: 51754037248.0000 - val_loss: 51946856448.0000
    Epoch 34/400
    119/119 [==============================] - 0s 4ms/step - loss: 51108229120.0000 - val_loss: 51198504960.0000
    Epoch 35/400
    119/119 [==============================] - 0s 4ms/step - loss: 50467258368.0000 - val_loss: 50579636224.0000
    Epoch 36/400
    119/119 [==============================] - 1s 4ms/step - loss: 49883639808.0000 - val_loss: 50022416384.0000
    Epoch 37/400
    119/119 [==============================] - 0s 4ms/step - loss: 49361973248.0000 - val_loss: 49408110592.0000
    Epoch 38/400
    119/119 [==============================] - 1s 5ms/step - loss: 48809889792.0000 - val_loss: 48900972544.0000
    Epoch 39/400
    119/119 [==============================] - 1s 4ms/step - loss: 48319438848.0000 - val_loss: 48320815104.0000
    Epoch 40/400
    119/119 [==============================] - 0s 4ms/step - loss: 47837798400.0000 - val_loss: 47823970304.0000
    Epoch 41/400
    119/119 [==============================] - 0s 4ms/step - loss: 47293091840.0000 - val_loss: 47290716160.0000
    Epoch 42/400
    119/119 [==============================] - 1s 4ms/step - loss: 46818193408.0000 - val_loss: 46892687360.0000
    Epoch 43/400
    119/119 [==============================] - 0s 4ms/step - loss: 46409412608.0000 - val_loss: 46315347968.0000
    Epoch 44/400
    119/119 [==============================] - 0s 4ms/step - loss: 45903118336.0000 - val_loss: 45858197504.0000
    Epoch 45/400
    119/119 [==============================] - 1s 4ms/step - loss: 45465300992.0000 - val_loss: 45402685440.0000
    Epoch 46/400
    119/119 [==============================] - 1s 4ms/step - loss: 45040570368.0000 - val_loss: 44971880448.0000
    Epoch 47/400
    119/119 [==============================] - 1s 4ms/step - loss: 44654358528.0000 - val_loss: 44654559232.0000
    Epoch 48/400
    119/119 [==============================] - 1s 4ms/step - loss: 44244918272.0000 - val_loss: 44116934656.0000
    Epoch 49/400
    119/119 [==============================] - 1s 4ms/step - loss: 43872579584.0000 - val_loss: 43727257600.0000
    Epoch 50/400
    119/119 [==============================] - 1s 4ms/step - loss: 43481309184.0000 - val_loss: 43368833024.0000
    Epoch 51/400
    119/119 [==============================] - 0s 4ms/step - loss: 43103027200.0000 - val_loss: 42936455168.0000
    Epoch 52/400
    119/119 [==============================] - 0s 4ms/step - loss: 42754543616.0000 - val_loss: 42573074432.0000
    Epoch 53/400
    119/119 [==============================] - 1s 5ms/step - loss: 42404024320.0000 - val_loss: 42207608832.0000
    Epoch 54/400
    119/119 [==============================] - 1s 5ms/step - loss: 42049716224.0000 - val_loss: 41846497280.0000
    Epoch 55/400
    119/119 [==============================] - 1s 4ms/step - loss: 41714085888.0000 - val_loss: 41523441664.0000
    Epoch 56/400
    119/119 [==============================] - 1s 4ms/step - loss: 41452142592.0000 - val_loss: 41178284032.0000
    Epoch 57/400
    119/119 [==============================] - 1s 4ms/step - loss: 41182494720.0000 - val_loss: 40854343680.0000
    Epoch 58/400
    119/119 [==============================] - 0s 4ms/step - loss: 40787329024.0000 - val_loss: 40473128960.0000
    Epoch 59/400
    119/119 [==============================] - 1s 4ms/step - loss: 40498180096.0000 - val_loss: 40168136704.0000
    Epoch 60/400
    119/119 [==============================] - 0s 4ms/step - loss: 40201633792.0000 - val_loss: 39865118720.0000
    Epoch 61/400
    119/119 [==============================] - 0s 4ms/step - loss: 39945228288.0000 - val_loss: 39597481984.0000
    Epoch 62/400
    119/119 [==============================] - 0s 4ms/step - loss: 39677849600.0000 - val_loss: 39392649216.0000
    Epoch 63/400
    119/119 [==============================] - 0s 4ms/step - loss: 39489093632.0000 - val_loss: 39112671232.0000
    Epoch 64/400
    119/119 [==============================] - 0s 4ms/step - loss: 39179141120.0000 - val_loss: 38938976256.0000
    Epoch 65/400
    119/119 [==============================] - 0s 4ms/step - loss: 38980825088.0000 - val_loss: 38586531840.0000
    Epoch 66/400
    119/119 [==============================] - 0s 4ms/step - loss: 38722412544.0000 - val_loss: 38333534208.0000
    Epoch 67/400
    119/119 [==============================] - 0s 4ms/step - loss: 38514388992.0000 - val_loss: 38100865024.0000
    Epoch 68/400
    119/119 [==============================] - 0s 4ms/step - loss: 38310752256.0000 - val_loss: 37904109568.0000
    Epoch 69/400
    119/119 [==============================] - 0s 4ms/step - loss: 38134161408.0000 - val_loss: 37717516288.0000
    Epoch 70/400
    119/119 [==============================] - 1s 4ms/step - loss: 37944619008.0000 - val_loss: 37502492672.0000
    Epoch 71/400
    119/119 [==============================] - 0s 4ms/step - loss: 37777305600.0000 - val_loss: 37356265472.0000
    Epoch 72/400
    119/119 [==============================] - 1s 4ms/step - loss: 37669957632.0000 - val_loss: 37151617024.0000
    Epoch 73/400
    119/119 [==============================] - 1s 4ms/step - loss: 37478739968.0000 - val_loss: 37002907648.0000
    Epoch 74/400
    119/119 [==============================] - 1s 4ms/step - loss: 37356507136.0000 - val_loss: 36857475072.0000
    Epoch 75/400
    119/119 [==============================] - 1s 6ms/step - loss: 37199106048.0000 - val_loss: 36706992128.0000
    Epoch 76/400
    119/119 [==============================] - 1s 5ms/step - loss: 37070725120.0000 - val_loss: 36572037120.0000
    Epoch 77/400
    119/119 [==============================] - 1s 4ms/step - loss: 36942344192.0000 - val_loss: 36463742976.0000
    Epoch 78/400
    119/119 [==============================] - 0s 4ms/step - loss: 36794789888.0000 - val_loss: 36282204160.0000
    Epoch 79/400
    119/119 [==============================] - 0s 4ms/step - loss: 36660609024.0000 - val_loss: 36210601984.0000
    Epoch 80/400
    119/119 [==============================] - 0s 4ms/step - loss: 36611592192.0000 - val_loss: 36019953664.0000
    Epoch 81/400
    119/119 [==============================] - 1s 4ms/step - loss: 36433047552.0000 - val_loss: 35913060352.0000
    Epoch 82/400
    119/119 [==============================] - 1s 4ms/step - loss: 36345032704.0000 - val_loss: 35761143808.0000
    Epoch 83/400
    119/119 [==============================] - 1s 6ms/step - loss: 36223795200.0000 - val_loss: 35655352320.0000
    Epoch 84/400
    119/119 [==============================] - 1s 6ms/step - loss: 36125147136.0000 - val_loss: 35592691712.0000
    Epoch 85/400
    119/119 [==============================] - 1s 9ms/step - loss: 36073578496.0000 - val_loss: 35465592832.0000
    Epoch 86/400
    119/119 [==============================] - 0s 4ms/step - loss: 35921547264.0000 - val_loss: 35410403328.0000
    Epoch 87/400
    119/119 [==============================] - 0s 4ms/step - loss: 35855192064.0000 - val_loss: 35226304512.0000
    Epoch 88/400
    119/119 [==============================] - 1s 6ms/step - loss: 35723292672.0000 - val_loss: 35144499200.0000
    Epoch 89/400
    119/119 [==============================] - 1s 4ms/step - loss: 35599233024.0000 - val_loss: 35193937920.0000
    Epoch 90/400
    119/119 [==============================] - 0s 4ms/step - loss: 35586846720.0000 - val_loss: 34953633792.0000
    Epoch 91/400
    119/119 [==============================] - 1s 5ms/step - loss: 35498708992.0000 - val_loss: 34841055232.0000
    Epoch 92/400
    119/119 [==============================] - 1s 5ms/step - loss: 35389026304.0000 - val_loss: 34779242496.0000
    Epoch 93/400
    119/119 [==============================] - 1s 4ms/step - loss: 35310166016.0000 - val_loss: 34687078400.0000
    Epoch 94/400
    119/119 [==============================] - 1s 5ms/step - loss: 35232993280.0000 - val_loss: 34617098240.0000
    Epoch 95/400
    119/119 [==============================] - 1s 5ms/step - loss: 35161628672.0000 - val_loss: 34527633408.0000
    Epoch 96/400
    119/119 [==============================] - 1s 6ms/step - loss: 35086663680.0000 - val_loss: 34438774784.0000
    Epoch 97/400
    119/119 [==============================] - 1s 5ms/step - loss: 35060682752.0000 - val_loss: 34373271552.0000
    Epoch 98/400
    119/119 [==============================] - 1s 4ms/step - loss: 34954670080.0000 - val_loss: 34336456704.0000
    Epoch 99/400
    119/119 [==============================] - 0s 4ms/step - loss: 34909155328.0000 - val_loss: 34231126016.0000
    Epoch 100/400
    119/119 [==============================] - 0s 4ms/step - loss: 34808279040.0000 - val_loss: 34168035328.0000
    Epoch 101/400
    119/119 [==============================] - 1s 4ms/step - loss: 34780205056.0000 - val_loss: 34076729344.0000
    Epoch 102/400
    119/119 [==============================] - 1s 5ms/step - loss: 34745602048.0000 - val_loss: 34023675904.0000
    Epoch 103/400
    119/119 [==============================] - 1s 5ms/step - loss: 34637246464.0000 - val_loss: 33974720512.0000
    Epoch 104/400
    119/119 [==============================] - 0s 4ms/step - loss: 34549497856.0000 - val_loss: 33917624320.0000
    Epoch 105/400
    119/119 [==============================] - 1s 6ms/step - loss: 34518003712.0000 - val_loss: 33837295616.0000
    Epoch 106/400
    119/119 [==============================] - 0s 4ms/step - loss: 34474201088.0000 - val_loss: 33777704960.0000
    Epoch 107/400
    119/119 [==============================] - 0s 4ms/step - loss: 34361835520.0000 - val_loss: 33856946176.0000
    Epoch 108/400
    119/119 [==============================] - 0s 4ms/step - loss: 34331301888.0000 - val_loss: 33655838720.0000
    Epoch 109/400
    119/119 [==============================] - 0s 4ms/step - loss: 34254782464.0000 - val_loss: 33625520128.0000
    Epoch 110/400
    119/119 [==============================] - 0s 3ms/step - loss: 34201724928.0000 - val_loss: 33723664384.0000
    Epoch 111/400
    119/119 [==============================] - 0s 4ms/step - loss: 34233278464.0000 - val_loss: 33487558656.0000
    Epoch 112/400
    119/119 [==============================] - 1s 5ms/step - loss: 34138687488.0000 - val_loss: 33438724096.0000
    Epoch 113/400
    119/119 [==============================] - 1s 6ms/step - loss: 34074767360.0000 - val_loss: 33424832512.0000
    Epoch 114/400
    119/119 [==============================] - 1s 6ms/step - loss: 34038579200.0000 - val_loss: 33328773120.0000
    Epoch 115/400
    119/119 [==============================] - 1s 7ms/step - loss: 34000424960.0000 - val_loss: 33395941376.0000
    Epoch 116/400
    119/119 [==============================] - 1s 7ms/step - loss: 33957474304.0000 - val_loss: 33228851200.0000
    Epoch 117/400
    119/119 [==============================] - 1s 4ms/step - loss: 33913470976.0000 - val_loss: 33433384960.0000
    Epoch 118/400
    119/119 [==============================] - 1s 4ms/step - loss: 33895516160.0000 - val_loss: 33135042560.0000
    Epoch 119/400
    119/119 [==============================] - 1s 4ms/step - loss: 33769232384.0000 - val_loss: 33077964800.0000
    Epoch 120/400
    119/119 [==============================] - 1s 4ms/step - loss: 33800398848.0000 - val_loss: 33066340352.0000
    Epoch 121/400
    119/119 [==============================] - 0s 4ms/step - loss: 33741430784.0000 - val_loss: 32986097664.0000
    Epoch 122/400
    119/119 [==============================] - 0s 4ms/step - loss: 33668720640.0000 - val_loss: 32946649088.0000
    Epoch 123/400
    119/119 [==============================] - 0s 4ms/step - loss: 33605836800.0000 - val_loss: 32911339520.0000
    Epoch 124/400
    119/119 [==============================] - 1s 4ms/step - loss: 33585418240.0000 - val_loss: 32863008768.0000
    Epoch 125/400
    119/119 [==============================] - 1s 5ms/step - loss: 33547632640.0000 - val_loss: 32848017408.0000
    Epoch 126/400
    119/119 [==============================] - 1s 5ms/step - loss: 33489756160.0000 - val_loss: 32818511872.0000
    Epoch 127/400
    119/119 [==============================] - 1s 4ms/step - loss: 33467619328.0000 - val_loss: 32751403008.0000
    Epoch 128/400
    119/119 [==============================] - 1s 5ms/step - loss: 33418377216.0000 - val_loss: 32698974208.0000
    Epoch 129/400
    119/119 [==============================] - 1s 5ms/step - loss: 33362558976.0000 - val_loss: 32780931072.0000
    Epoch 130/400
    119/119 [==============================] - 1s 4ms/step - loss: 33360134144.0000 - val_loss: 32711196672.0000
    Epoch 131/400
    119/119 [==============================] - 1s 4ms/step - loss: 33323470848.0000 - val_loss: 32592553984.0000
    Epoch 132/400
    119/119 [==============================] - 0s 4ms/step - loss: 33242748928.0000 - val_loss: 32595261440.0000
    Epoch 133/400
    119/119 [==============================] - 1s 5ms/step - loss: 33243228160.0000 - val_loss: 32520036352.0000
    Epoch 134/400
    119/119 [==============================] - 1s 4ms/step - loss: 33185863680.0000 - val_loss: 32485492736.0000
    Epoch 135/400
    119/119 [==============================] - 1s 4ms/step - loss: 33202329600.0000 - val_loss: 32437256192.0000
    Epoch 136/400
    119/119 [==============================] - 1s 4ms/step - loss: 33124554752.0000 - val_loss: 32426762240.0000
    Epoch 137/400
    119/119 [==============================] - 1s 5ms/step - loss: 33095264256.0000 - val_loss: 32432580608.0000
    Epoch 138/400
    119/119 [==============================] - 1s 5ms/step - loss: 33079494656.0000 - val_loss: 32339654656.0000
    Epoch 139/400
    119/119 [==============================] - 1s 5ms/step - loss: 33036331008.0000 - val_loss: 32311087104.0000
    Epoch 140/400
    119/119 [==============================] - 1s 6ms/step - loss: 32993146880.0000 - val_loss: 32274884608.0000
    Epoch 141/400
    119/119 [==============================] - 1s 7ms/step - loss: 32939505664.0000 - val_loss: 32234690560.0000
    Epoch 142/400
    119/119 [==============================] - 1s 5ms/step - loss: 32946239488.0000 - val_loss: 32346648576.0000
    Epoch 143/400
    119/119 [==============================] - 1s 4ms/step - loss: 32976494592.0000 - val_loss: 32209743872.0000
    Epoch 144/400
    119/119 [==============================] - 1s 7ms/step - loss: 32835778560.0000 - val_loss: 32269400064.0000
    Epoch 145/400
    119/119 [==============================] - 0s 4ms/step - loss: 32861861888.0000 - val_loss: 32150603776.0000
    Epoch 146/400
    119/119 [==============================] - 1s 5ms/step - loss: 32801189888.0000 - val_loss: 32100894720.0000
    Epoch 147/400
    119/119 [==============================] - 0s 4ms/step - loss: 32765409280.0000 - val_loss: 32073521152.0000
    Epoch 148/400
    119/119 [==============================] - 1s 5ms/step - loss: 32752420864.0000 - val_loss: 32073134080.0000
    Epoch 149/400
    119/119 [==============================] - 1s 5ms/step - loss: 32722487296.0000 - val_loss: 31999414272.0000
    Epoch 150/400
    119/119 [==============================] - 0s 4ms/step - loss: 32712230912.0000 - val_loss: 31998859264.0000
    Epoch 151/400
    119/119 [==============================] - 1s 8ms/step - loss: 32632576000.0000 - val_loss: 31968798720.0000
    Epoch 152/400
    119/119 [==============================] - 0s 4ms/step - loss: 32629028864.0000 - val_loss: 31905841152.0000
    Epoch 153/400
    119/119 [==============================] - 0s 4ms/step - loss: 32586975232.0000 - val_loss: 31937443840.0000
    Epoch 154/400
    119/119 [==============================] - 0s 4ms/step - loss: 32582688768.0000 - val_loss: 31870531584.0000
    Epoch 155/400
    119/119 [==============================] - 0s 4ms/step - loss: 32558082048.0000 - val_loss: 31834492928.0000
    Epoch 156/400
    119/119 [==============================] - 0s 4ms/step - loss: 32557350912.0000 - val_loss: 31807420416.0000
    Epoch 157/400
    119/119 [==============================] - 1s 5ms/step - loss: 32479752192.0000 - val_loss: 31810050048.0000
    Epoch 158/400
    119/119 [==============================] - 1s 5ms/step - loss: 32445151232.0000 - val_loss: 31761074176.0000
    Epoch 159/400
    119/119 [==============================] - 1s 5ms/step - loss: 32459544576.0000 - val_loss: 31779917824.0000
    Epoch 160/400
    119/119 [==============================] - 1s 4ms/step - loss: 32408246272.0000 - val_loss: 31706101760.0000
    Epoch 161/400
    119/119 [==============================] - 1s 6ms/step - loss: 32349450240.0000 - val_loss: 31758028800.0000
    Epoch 162/400
    119/119 [==============================] - 1s 4ms/step - loss: 32349767680.0000 - val_loss: 31685734400.0000
    Epoch 163/400
    119/119 [==============================] - 0s 4ms/step - loss: 32310118400.0000 - val_loss: 31634892800.0000
    Epoch 164/400
    119/119 [==============================] - 1s 5ms/step - loss: 32294410240.0000 - val_loss: 31599032320.0000
    Epoch 165/400
    119/119 [==============================] - 1s 5ms/step - loss: 32260337664.0000 - val_loss: 31569410048.0000
    Epoch 166/400
    119/119 [==============================] - 1s 5ms/step - loss: 32258142208.0000 - val_loss: 31571226624.0000
    Epoch 167/400
    119/119 [==============================] - 1s 6ms/step - loss: 32206004224.0000 - val_loss: 31524333568.0000
    Epoch 168/400
    119/119 [==============================] - 1s 11ms/step - loss: 32201977856.0000 - val_loss: 31498917888.0000
    Epoch 169/400
    119/119 [==============================] - 1s 5ms/step - loss: 32169150464.0000 - val_loss: 31481354240.0000
    Epoch 170/400
    119/119 [==============================] - 1s 5ms/step - loss: 32115527680.0000 - val_loss: 31616526336.0000
    Epoch 171/400
    119/119 [==============================] - 1s 5ms/step - loss: 32156749824.0000 - val_loss: 31526305792.0000
    Epoch 172/400
    119/119 [==============================] - 1s 5ms/step - loss: 32067667968.0000 - val_loss: 31407917056.0000
    Epoch 173/400
    119/119 [==============================] - 1s 5ms/step - loss: 32074084352.0000 - val_loss: 31433373696.0000
    Epoch 174/400
    119/119 [==============================] - 1s 5ms/step - loss: 32044259328.0000 - val_loss: 31398754304.0000
    Epoch 175/400
    119/119 [==============================] - 0s 4ms/step - loss: 32045238272.0000 - val_loss: 31348228096.0000
    Epoch 176/400
    119/119 [==============================] - 0s 4ms/step - loss: 31992524800.0000 - val_loss: 31321489408.0000
    Epoch 177/400
    119/119 [==============================] - 1s 7ms/step - loss: 32023920640.0000 - val_loss: 31302725632.0000
    Epoch 178/400
    119/119 [==============================] - 1s 5ms/step - loss: 32019294208.0000 - val_loss: 31265400832.0000
    Epoch 179/400
    119/119 [==============================] - 1s 6ms/step - loss: 31916423168.0000 - val_loss: 31272761344.0000
    Epoch 180/400
    119/119 [==============================] - 1s 5ms/step - loss: 31893999616.0000 - val_loss: 31258988544.0000
    Epoch 181/400
    119/119 [==============================] - 1s 5ms/step - loss: 31858165760.0000 - val_loss: 31277465600.0000
    Epoch 182/400
    119/119 [==============================] - 1s 4ms/step - loss: 31846498304.0000 - val_loss: 31192520704.0000
    Epoch 183/400
    119/119 [==============================] - 1s 4ms/step - loss: 31865411584.0000 - val_loss: 31165003776.0000
    Epoch 184/400
    119/119 [==============================] - 1s 4ms/step - loss: 31822919680.0000 - val_loss: 31129307136.0000
    Epoch 185/400
    119/119 [==============================] - 1s 6ms/step - loss: 31822893056.0000 - val_loss: 31114536960.0000
    Epoch 186/400
    119/119 [==============================] - 1s 4ms/step - loss: 31770494976.0000 - val_loss: 31115298816.0000
    Epoch 187/400
    119/119 [==============================] - 1s 5ms/step - loss: 31756298240.0000 - val_loss: 31071059968.0000
    Epoch 188/400
    119/119 [==============================] - 1s 4ms/step - loss: 31750432768.0000 - val_loss: 31101499392.0000
    Epoch 189/400
    119/119 [==============================] - 1s 4ms/step - loss: 31729238016.0000 - val_loss: 31016488960.0000
    Epoch 190/400
    119/119 [==============================] - 0s 4ms/step - loss: 31693805568.0000 - val_loss: 31006816256.0000
    Epoch 191/400
    119/119 [==============================] - 0s 4ms/step - loss: 31658534912.0000 - val_loss: 30996928512.0000
    Epoch 192/400
    119/119 [==============================] - 1s 4ms/step - loss: 31629377536.0000 - val_loss: 31094818816.0000
    Epoch 193/400
    119/119 [==============================] - 1s 10ms/step - loss: 31634696192.0000 - val_loss: 30948794368.0000
    Epoch 194/400
    119/119 [==============================] - 1s 9ms/step - loss: 31599523840.0000 - val_loss: 30926960640.0000
    Epoch 195/400
    119/119 [==============================] - 1s 6ms/step - loss: 31591055360.0000 - val_loss: 30945159168.0000
    Epoch 196/400
    119/119 [==============================] - 1s 7ms/step - loss: 31591434240.0000 - val_loss: 30902095872.0000
    Epoch 197/400
    119/119 [==============================] - 0s 4ms/step - loss: 31560046592.0000 - val_loss: 30885306368.0000
    Epoch 198/400
    119/119 [==============================] - 1s 4ms/step - loss: 31640944640.0000 - val_loss: 30854107136.0000
    Epoch 199/400
    119/119 [==============================] - 0s 4ms/step - loss: 31520225280.0000 - val_loss: 30841088000.0000
    Epoch 200/400
    119/119 [==============================] - 1s 5ms/step - loss: 31482935296.0000 - val_loss: 30824667136.0000
    Epoch 201/400
    119/119 [==============================] - 1s 5ms/step - loss: 31456313344.0000 - val_loss: 30804037632.0000
    Epoch 202/400
    119/119 [==============================] - 1s 5ms/step - loss: 31479623680.0000 - val_loss: 30789431296.0000
    Epoch 203/400
    119/119 [==============================] - 1s 5ms/step - loss: 31451041792.0000 - val_loss: 30829490176.0000
    Epoch 204/400
    119/119 [==============================] - 1s 4ms/step - loss: 31406123008.0000 - val_loss: 30804166656.0000
    Epoch 205/400
    119/119 [==============================] - 0s 4ms/step - loss: 31405555712.0000 - val_loss: 30762692608.0000
    Epoch 206/400
    119/119 [==============================] - 1s 4ms/step - loss: 31351013376.0000 - val_loss: 30731145216.0000
    Epoch 207/400
    119/119 [==============================] - 1s 5ms/step - loss: 31356680192.0000 - val_loss: 30718464000.0000
    Epoch 208/400
    119/119 [==============================] - 1s 5ms/step - loss: 31300014080.0000 - val_loss: 30737395712.0000
    Epoch 209/400
    119/119 [==============================] - 1s 4ms/step - loss: 31331235840.0000 - val_loss: 30711398400.0000
    Epoch 210/400
    119/119 [==============================] - 1s 6ms/step - loss: 31295119360.0000 - val_loss: 30664759296.0000
    Epoch 211/400
    119/119 [==============================] - 1s 6ms/step - loss: 31295911936.0000 - val_loss: 30636335104.0000
    Epoch 212/400
    119/119 [==============================] - 1s 6ms/step - loss: 31241056256.0000 - val_loss: 30803505152.0000
    Epoch 213/400
    119/119 [==============================] - 1s 6ms/step - loss: 31315855360.0000 - val_loss: 30609137664.0000
    Epoch 214/400
    119/119 [==============================] - 1s 5ms/step - loss: 31232217088.0000 - val_loss: 30768676864.0000
    Epoch 215/400
    119/119 [==============================] - 1s 9ms/step - loss: 31205169152.0000 - val_loss: 30740848640.0000
    Epoch 216/400
    119/119 [==============================] - 1s 4ms/step - loss: 31181916160.0000 - val_loss: 30551660544.0000
    Epoch 217/400
    119/119 [==============================] - 1s 5ms/step - loss: 31161241600.0000 - val_loss: 30526683136.0000
    Epoch 218/400
    119/119 [==============================] - 1s 4ms/step - loss: 31133265920.0000 - val_loss: 30512062464.0000
    Epoch 219/400
    119/119 [==============================] - 1s 4ms/step - loss: 31122898944.0000 - val_loss: 30563702784.0000
    Epoch 220/400
    119/119 [==============================] - 0s 4ms/step - loss: 31155886080.0000 - val_loss: 30498392064.0000
    Epoch 221/400
    119/119 [==============================] - 1s 6ms/step - loss: 31082637312.0000 - val_loss: 30620618752.0000
    Epoch 222/400
    119/119 [==============================] - 2s 18ms/step - loss: 31146919936.0000 - val_loss: 30593173504.0000
    Epoch 223/400
    119/119 [==============================] - 1s 5ms/step - loss: 31080411136.0000 - val_loss: 30432223232.0000
    Epoch 224/400
    119/119 [==============================] - 1s 5ms/step - loss: 31052908544.0000 - val_loss: 30423545856.0000
    Epoch 225/400
    119/119 [==============================] - 1s 4ms/step - loss: 31052896256.0000 - val_loss: 30437883904.0000
    Epoch 226/400
    119/119 [==============================] - 1s 5ms/step - loss: 31027875840.0000 - val_loss: 30440626176.0000
    Epoch 227/400
    119/119 [==============================] - 1s 9ms/step - loss: 31023998976.0000 - val_loss: 30408445952.0000
    Epoch 228/400
    119/119 [==============================] - 0s 4ms/step - loss: 31004864512.0000 - val_loss: 30560290816.0000
    Epoch 229/400
    119/119 [==============================] - 0s 4ms/step - loss: 30971461632.0000 - val_loss: 30350211072.0000
    Epoch 230/400
    119/119 [==============================] - 0s 4ms/step - loss: 30923720704.0000 - val_loss: 30318256128.0000
    Epoch 231/400
    119/119 [==============================] - 0s 4ms/step - loss: 30924208128.0000 - val_loss: 30302146560.0000
    Epoch 232/400
    119/119 [==============================] - 1s 8ms/step - loss: 30905868288.0000 - val_loss: 30301145088.0000
    Epoch 233/400
    119/119 [==============================] - 1s 7ms/step - loss: 30913478656.0000 - val_loss: 30303815680.0000
    Epoch 234/400
    119/119 [==============================] - 0s 4ms/step - loss: 30896781312.0000 - val_loss: 30270593024.0000
    Epoch 235/400
    119/119 [==============================] - 1s 5ms/step - loss: 30859835392.0000 - val_loss: 30289786880.0000
    Epoch 236/400
    119/119 [==============================] - 1s 4ms/step - loss: 30838730752.0000 - val_loss: 30243256320.0000
    Epoch 237/400
    119/119 [==============================] - 1s 5ms/step - loss: 30810773504.0000 - val_loss: 30272897024.0000
    Epoch 238/400
    119/119 [==============================] - 0s 4ms/step - loss: 30833817600.0000 - val_loss: 30303690752.0000
    Epoch 239/400
    119/119 [==============================] - 0s 4ms/step - loss: 30816460800.0000 - val_loss: 30187366400.0000
    Epoch 240/400
    119/119 [==============================] - 0s 4ms/step - loss: 30773817344.0000 - val_loss: 30177566720.0000
    Epoch 241/400
    119/119 [==============================] - 0s 4ms/step - loss: 30804518912.0000 - val_loss: 30262992896.0000
    Epoch 242/400
    119/119 [==============================] - 1s 11ms/step - loss: 30750894080.0000 - val_loss: 30163668992.0000
    Epoch 243/400
    119/119 [==============================] - 1s 4ms/step - loss: 30724818944.0000 - val_loss: 30155071488.0000
    Epoch 244/400
    119/119 [==============================] - 0s 4ms/step - loss: 30736218112.0000 - val_loss: 30277896192.0000
    Epoch 245/400
    119/119 [==============================] - 0s 4ms/step - loss: 30718003200.0000 - val_loss: 30140772352.0000
    Epoch 246/400
    119/119 [==============================] - 1s 5ms/step - loss: 30656667648.0000 - val_loss: 30109837312.0000
    Epoch 247/400
    119/119 [==============================] - 1s 4ms/step - loss: 30647197696.0000 - val_loss: 30100387840.0000
    Epoch 248/400
    119/119 [==============================] - 1s 6ms/step - loss: 30649288704.0000 - val_loss: 30084972544.0000
    Epoch 249/400
    119/119 [==============================] - 1s 5ms/step - loss: 30657359872.0000 - val_loss: 30049935360.0000
    Epoch 250/400
    119/119 [==============================] - 0s 4ms/step - loss: 30604466176.0000 - val_loss: 30089299968.0000
    Epoch 251/400
    119/119 [==============================] - 1s 4ms/step - loss: 30583478272.0000 - val_loss: 30050656256.0000
    Epoch 252/400
    119/119 [==============================] - 1s 9ms/step - loss: 30603427840.0000 - val_loss: 30146123776.0000
    Epoch 253/400
    119/119 [==============================] - 0s 4ms/step - loss: 30566707200.0000 - val_loss: 29994825728.0000
    Epoch 254/400
    119/119 [==============================] - 0s 4ms/step - loss: 30562691072.0000 - val_loss: 29986633728.0000
    Epoch 255/400
    119/119 [==============================] - 0s 4ms/step - loss: 30510249984.0000 - val_loss: 29991120896.0000
    Epoch 256/400
    119/119 [==============================] - 1s 6ms/step - loss: 30509965312.0000 - val_loss: 29934528512.0000
    Epoch 257/400
    119/119 [==============================] - 0s 4ms/step - loss: 30508918784.0000 - val_loss: 29965424640.0000
    Epoch 258/400
    119/119 [==============================] - 1s 4ms/step - loss: 30492401664.0000 - val_loss: 29932175360.0000
    Epoch 259/400
    119/119 [==============================] - 1s 4ms/step - loss: 30459580416.0000 - val_loss: 29898805248.0000
    Epoch 260/400
    119/119 [==============================] - 1s 5ms/step - loss: 30438451200.0000 - val_loss: 29910124544.0000
    Epoch 261/400
    119/119 [==============================] - 1s 4ms/step - loss: 30458095616.0000 - val_loss: 30067179520.0000
    Epoch 262/400
    119/119 [==============================] - 1s 8ms/step - loss: 30407942144.0000 - val_loss: 29862230016.0000
    Epoch 263/400
    119/119 [==============================] - 1s 7ms/step - loss: 30407020544.0000 - val_loss: 29859532800.0000
    Epoch 264/400
    119/119 [==============================] - 0s 4ms/step - loss: 30388131840.0000 - val_loss: 29843937280.0000
    Epoch 265/400
    119/119 [==============================] - 1s 4ms/step - loss: 30366545920.0000 - val_loss: 29827641344.0000
    Epoch 266/400
    119/119 [==============================] - 1s 5ms/step - loss: 30354798592.0000 - val_loss: 29813229568.0000
    Epoch 267/400
    119/119 [==============================] - 0s 4ms/step - loss: 30335641600.0000 - val_loss: 29822054400.0000
    Epoch 268/400
    119/119 [==============================] - 1s 5ms/step - loss: 30321997824.0000 - val_loss: 29805144064.0000
    Epoch 269/400
    119/119 [==============================] - 1s 5ms/step - loss: 30308706304.0000 - val_loss: 29779587072.0000
    Epoch 270/400
    119/119 [==============================] - 1s 5ms/step - loss: 30295103488.0000 - val_loss: 29774678016.0000
    Epoch 271/400
    119/119 [==============================] - 0s 4ms/step - loss: 30306076672.0000 - val_loss: 29743890432.0000
    Epoch 272/400
    119/119 [==============================] - 1s 12ms/step - loss: 30269896704.0000 - val_loss: 29732923392.0000
    Epoch 273/400
    119/119 [==============================] - 1s 4ms/step - loss: 30246950912.0000 - val_loss: 29737250816.0000
    Epoch 274/400
    119/119 [==============================] - 1s 4ms/step - loss: 30236530688.0000 - val_loss: 29751138304.0000
    Epoch 275/400
    119/119 [==============================] - 0s 4ms/step - loss: 30226626560.0000 - val_loss: 29740828672.0000
    Epoch 276/400
    119/119 [==============================] - 0s 4ms/step - loss: 30228785152.0000 - val_loss: 29734088704.0000
    Epoch 277/400
    119/119 [==============================] - 0s 4ms/step - loss: 30211014656.0000 - val_loss: 29669496832.0000
    Epoch 278/400
    119/119 [==============================] - 1s 4ms/step - loss: 30172549120.0000 - val_loss: 29757622272.0000
    Epoch 279/400
    119/119 [==============================] - 0s 4ms/step - loss: 30129014784.0000 - val_loss: 29672527872.0000
    Epoch 280/400
    119/119 [==============================] - 0s 4ms/step - loss: 30109999104.0000 - val_loss: 29627807744.0000
    Epoch 281/400
    119/119 [==============================] - 1s 6ms/step - loss: 30135410688.0000 - val_loss: 29626871808.0000
    Epoch 282/400
    119/119 [==============================] - 1s 11ms/step - loss: 30098835456.0000 - val_loss: 29665519616.0000
    Epoch 283/400
    119/119 [==============================] - 0s 4ms/step - loss: 30058547200.0000 - val_loss: 29608005632.0000
    Epoch 284/400
    119/119 [==============================] - 1s 6ms/step - loss: 30095706112.0000 - val_loss: 29580136448.0000
    Epoch 285/400
    119/119 [==============================] - 0s 4ms/step - loss: 30085949440.0000 - val_loss: 29579976704.0000
    Epoch 286/400
    119/119 [==============================] - 1s 9ms/step - loss: 30046302208.0000 - val_loss: 29538136064.0000
    Epoch 287/400
    119/119 [==============================] - 0s 4ms/step - loss: 30053414912.0000 - val_loss: 29538672640.0000
    Epoch 288/400
    119/119 [==============================] - 0s 4ms/step - loss: 30071853056.0000 - val_loss: 29514932224.0000
    Epoch 289/400
    119/119 [==============================] - 1s 4ms/step - loss: 29974800384.0000 - val_loss: 29540259840.0000
    Epoch 290/400
    119/119 [==============================] - 1s 5ms/step - loss: 29998839808.0000 - val_loss: 29494906880.0000
    Epoch 291/400
    119/119 [==============================] - 2s 15ms/step - loss: 29968089088.0000 - val_loss: 29465155584.0000
    Epoch 292/400
    119/119 [==============================] - 1s 5ms/step - loss: 29986402304.0000 - val_loss: 29480957952.0000
    Epoch 293/400
    119/119 [==============================] - 1s 5ms/step - loss: 29924913152.0000 - val_loss: 29469962240.0000
    Epoch 294/400
    119/119 [==============================] - 1s 5ms/step - loss: 29966925824.0000 - val_loss: 29475670016.0000
    Epoch 295/400
    119/119 [==============================] - 1s 4ms/step - loss: 29884549120.0000 - val_loss: 29417787392.0000
    Epoch 296/400
    119/119 [==============================] - 1s 4ms/step - loss: 29949163520.0000 - val_loss: 29407936512.0000
    Epoch 297/400
    119/119 [==============================] - 1s 5ms/step - loss: 29898231808.0000 - val_loss: 29402224640.0000
    Epoch 298/400
    119/119 [==============================] - 1s 5ms/step - loss: 29837039616.0000 - val_loss: 29379235840.0000
    Epoch 299/400
    119/119 [==============================] - 1s 5ms/step - loss: 29842778112.0000 - val_loss: 29395865600.0000
    Epoch 300/400
    119/119 [==============================] - 0s 4ms/step - loss: 29852088320.0000 - val_loss: 29398980608.0000
    Epoch 301/400
    119/119 [==============================] - 0s 4ms/step - loss: 29836068864.0000 - val_loss: 29392824320.0000
    Epoch 302/400
    119/119 [==============================] - 1s 6ms/step - loss: 29877760000.0000 - val_loss: 29323577344.0000
    Epoch 303/400
    119/119 [==============================] - 0s 4ms/step - loss: 29806243840.0000 - val_loss: 29317937152.0000
    Epoch 304/400
    119/119 [==============================] - 1s 4ms/step - loss: 29747746816.0000 - val_loss: 29313998848.0000
    Epoch 305/400
    119/119 [==============================] - 0s 4ms/step - loss: 29746333696.0000 - val_loss: 29289775104.0000
    Epoch 306/400
    119/119 [==============================] - 1s 5ms/step - loss: 29731889152.0000 - val_loss: 29286090752.0000
    Epoch 307/400
    119/119 [==============================] - 1s 5ms/step - loss: 29709326336.0000 - val_loss: 29251928064.0000
    Epoch 308/400
    119/119 [==============================] - 1s 4ms/step - loss: 29712087040.0000 - val_loss: 29254727680.0000
    Epoch 309/400
    119/119 [==============================] - 1s 5ms/step - loss: 29666349056.0000 - val_loss: 29228599296.0000
    Epoch 310/400
    119/119 [==============================] - 0s 4ms/step - loss: 29675065344.0000 - val_loss: 29261019136.0000
    Epoch 311/400
    119/119 [==============================] - 0s 4ms/step - loss: 29668380672.0000 - val_loss: 29221257216.0000
    Epoch 312/400
    119/119 [==============================] - 1s 6ms/step - loss: 29633316864.0000 - val_loss: 29180774400.0000
    Epoch 313/400
    119/119 [==============================] - 0s 4ms/step - loss: 29601019904.0000 - val_loss: 29172883456.0000
    Epoch 314/400
    119/119 [==============================] - 1s 4ms/step - loss: 29655885824.0000 - val_loss: 29244469248.0000
    Epoch 315/400
    119/119 [==============================] - 0s 4ms/step - loss: 29600133120.0000 - val_loss: 29162168320.0000
    Epoch 316/400
    119/119 [==============================] - 0s 3ms/step - loss: 29620041728.0000 - val_loss: 29118085120.0000
    Epoch 317/400
    119/119 [==============================] - 0s 4ms/step - loss: 29497792512.0000 - val_loss: 29125963776.0000
    Epoch 318/400
    119/119 [==============================] - 0s 4ms/step - loss: 29541787648.0000 - val_loss: 29132199936.0000
    Epoch 319/400
    119/119 [==============================] - 0s 3ms/step - loss: 29523230720.0000 - val_loss: 29111199744.0000
    Epoch 320/400
    119/119 [==============================] - 0s 4ms/step - loss: 29491238912.0000 - val_loss: 29119825920.0000
    Epoch 321/400
    119/119 [==============================] - 1s 5ms/step - loss: 29513070592.0000 - val_loss: 29069363200.0000
    Epoch 322/400
    119/119 [==============================] - 1s 6ms/step - loss: 29434286080.0000 - val_loss: 29069096960.0000
    Epoch 323/400
    119/119 [==============================] - 1s 7ms/step - loss: 29506703360.0000 - val_loss: 29070366720.0000
    Epoch 324/400
    119/119 [==============================] - 1s 9ms/step - loss: 29399660544.0000 - val_loss: 29124941824.0000
    Epoch 325/400
    119/119 [==============================] - 1s 5ms/step - loss: 29407932416.0000 - val_loss: 29005174784.0000
    Epoch 326/400
    119/119 [==============================] - 1s 5ms/step - loss: 29431402496.0000 - val_loss: 28992669696.0000
    Epoch 327/400
    119/119 [==============================] - 1s 4ms/step - loss: 29345486848.0000 - val_loss: 28980330496.0000
    Epoch 328/400
    119/119 [==============================] - 1s 5ms/step - loss: 29381265408.0000 - val_loss: 29069594624.0000
    Epoch 329/400
    119/119 [==============================] - 0s 4ms/step - loss: 29296750592.0000 - val_loss: 28939388928.0000
    Epoch 330/400
    119/119 [==============================] - 0s 4ms/step - loss: 29323182080.0000 - val_loss: 28925894656.0000
    Epoch 331/400
    119/119 [==============================] - 1s 4ms/step - loss: 29256859648.0000 - val_loss: 29027944448.0000
    Epoch 332/400
    119/119 [==============================] - 0s 4ms/step - loss: 29264480256.0000 - val_loss: 28886095872.0000
    Epoch 333/400
    119/119 [==============================] - 1s 4ms/step - loss: 29211852800.0000 - val_loss: 28899401728.0000
    Epoch 334/400
    119/119 [==============================] - 1s 5ms/step - loss: 29222293504.0000 - val_loss: 28872040448.0000
    Epoch 335/400
    119/119 [==============================] - 1s 4ms/step - loss: 29197152256.0000 - val_loss: 28843649024.0000
    Epoch 336/400
    119/119 [==============================] - 1s 4ms/step - loss: 29179158528.0000 - val_loss: 28840237056.0000
    Epoch 337/400
    119/119 [==============================] - 1s 5ms/step - loss: 29172113408.0000 - val_loss: 28799442944.0000
    Epoch 338/400
    119/119 [==============================] - 1s 4ms/step - loss: 29126209536.0000 - val_loss: 28801978368.0000
    Epoch 339/400
    119/119 [==============================] - 1s 5ms/step - loss: 29081731072.0000 - val_loss: 28779087872.0000
    Epoch 340/400
    119/119 [==============================] - 1s 4ms/step - loss: 29071036416.0000 - val_loss: 28848115712.0000
    Epoch 341/400
    119/119 [==============================] - 0s 4ms/step - loss: 29051541504.0000 - val_loss: 28779655168.0000
    Epoch 342/400
    119/119 [==============================] - 1s 4ms/step - loss: 29031444480.0000 - val_loss: 28755236864.0000
    Epoch 343/400
    119/119 [==============================] - 1s 5ms/step - loss: 29006133248.0000 - val_loss: 28770035712.0000
    Epoch 344/400
    119/119 [==============================] - 1s 6ms/step - loss: 28924264448.0000 - val_loss: 28965580800.0000
    Epoch 345/400
    119/119 [==============================] - 0s 4ms/step - loss: 28990525440.0000 - val_loss: 28703014912.0000
    Epoch 346/400
    119/119 [==============================] - 1s 5ms/step - loss: 28921376768.0000 - val_loss: 28665581568.0000
    Epoch 347/400
    119/119 [==============================] - 1s 4ms/step - loss: 28961771520.0000 - val_loss: 28676950016.0000
    Epoch 348/400
    119/119 [==============================] - 1s 6ms/step - loss: 28862904320.0000 - val_loss: 28792977408.0000
    Epoch 349/400
    119/119 [==============================] - 1s 4ms/step - loss: 28891367424.0000 - val_loss: 28633659392.0000
    Epoch 350/400
    119/119 [==============================] - 1s 6ms/step - loss: 28851484672.0000 - val_loss: 28603676672.0000
    Epoch 351/400
    119/119 [==============================] - 1s 6ms/step - loss: 28821821440.0000 - val_loss: 28701089792.0000
    Epoch 352/400
    119/119 [==============================] - 1s 4ms/step - loss: 28822765568.0000 - val_loss: 28573693952.0000
    Epoch 353/400
    119/119 [==============================] - 0s 4ms/step - loss: 28812259328.0000 - val_loss: 28540383232.0000
    Epoch 354/400
    119/119 [==============================] - 0s 4ms/step - loss: 28746209280.0000 - val_loss: 28547162112.0000
    Epoch 355/400
    119/119 [==============================] - 0s 4ms/step - loss: 28722804736.0000 - val_loss: 28503027712.0000
    Epoch 356/400
    119/119 [==============================] - 0s 4ms/step - loss: 28672088064.0000 - val_loss: 28469999616.0000
    Epoch 357/400
    119/119 [==============================] - 0s 4ms/step - loss: 28699213824.0000 - val_loss: 28465686528.0000
    Epoch 358/400
    119/119 [==============================] - 0s 4ms/step - loss: 28655859712.0000 - val_loss: 28476325888.0000
    Epoch 359/400
    119/119 [==============================] - 1s 5ms/step - loss: 28619065344.0000 - val_loss: 28416081920.0000
    Epoch 360/400
    119/119 [==============================] - 1s 5ms/step - loss: 28614766592.0000 - val_loss: 28401113088.0000
    Epoch 361/400
    119/119 [==============================] - 1s 6ms/step - loss: 28567920640.0000 - val_loss: 28411342848.0000
    Epoch 362/400
    119/119 [==============================] - 1s 5ms/step - loss: 28515084288.0000 - val_loss: 28401190912.0000
    Epoch 363/400
    119/119 [==============================] - 1s 6ms/step - loss: 28491020288.0000 - val_loss: 28328323072.0000
    Epoch 364/400
    119/119 [==============================] - 1s 4ms/step - loss: 28492257280.0000 - val_loss: 28484376576.0000
    Epoch 365/400
    119/119 [==============================] - 0s 4ms/step - loss: 28455927808.0000 - val_loss: 28346632192.0000
    Epoch 366/400
    119/119 [==============================] - 0s 4ms/step - loss: 28445480960.0000 - val_loss: 28316850176.0000
    Epoch 367/400
    119/119 [==============================] - 1s 4ms/step - loss: 28420624384.0000 - val_loss: 28272584704.0000
    Epoch 368/400
    119/119 [==============================] - 0s 4ms/step - loss: 28396548096.0000 - val_loss: 28263983104.0000
    Epoch 369/400
    119/119 [==============================] - 1s 5ms/step - loss: 28330293248.0000 - val_loss: 28224614400.0000
    Epoch 370/400
    119/119 [==============================] - 1s 5ms/step - loss: 28340264960.0000 - val_loss: 28211470336.0000
    Epoch 371/400
    119/119 [==============================] - 1s 4ms/step - loss: 28373737472.0000 - val_loss: 28193019904.0000
    Epoch 372/400
    119/119 [==============================] - 1s 4ms/step - loss: 28270874624.0000 - val_loss: 28239413248.0000
    Epoch 373/400
    119/119 [==============================] - 1s 5ms/step - loss: 28296251392.0000 - val_loss: 28366055424.0000
    Epoch 374/400
    119/119 [==============================] - 1s 5ms/step - loss: 28314957824.0000 - val_loss: 28217569280.0000
    Epoch 375/400
    119/119 [==============================] - 1s 8ms/step - loss: 28197591040.0000 - val_loss: 28121079808.0000
    Epoch 376/400
    119/119 [==============================] - 1s 5ms/step - loss: 28217509888.0000 - val_loss: 28144156672.0000
    Epoch 377/400
    119/119 [==============================] - 1s 5ms/step - loss: 28210878464.0000 - val_loss: 28180185088.0000
    Epoch 378/400
    119/119 [==============================] - 2s 17ms/step - loss: 28332294144.0000 - val_loss: 28280180736.0000
    Epoch 379/400
    119/119 [==============================] - 1s 5ms/step - loss: 28154183680.0000 - val_loss: 28119023616.0000
    Epoch 380/400
    119/119 [==============================] - 1s 5ms/step - loss: 28144752640.0000 - val_loss: 28119920640.0000
    Epoch 381/400
    119/119 [==============================] - 5s 42ms/step - loss: 28081932288.0000 - val_loss: 28029755392.0000
    Epoch 382/400
    119/119 [==============================] - 1s 10ms/step - loss: 28083562496.0000 - val_loss: 28032782336.0000
    Epoch 383/400
    119/119 [==============================] - 1s 7ms/step - loss: 28022614016.0000 - val_loss: 28005138432.0000
    Epoch 384/400
    119/119 [==============================] - 1s 7ms/step - loss: 28016242688.0000 - val_loss: 27994540032.0000
    Epoch 385/400
    119/119 [==============================] - 1s 6ms/step - loss: 28037967872.0000 - val_loss: 28004800512.0000
    Epoch 386/400
    119/119 [==============================] - 1s 7ms/step - loss: 28002447360.0000 - val_loss: 27949332480.0000
    Epoch 387/400
    119/119 [==============================] - 1s 7ms/step - loss: 27999545344.0000 - val_loss: 27934724096.0000
    Epoch 388/400
    119/119 [==============================] - 1s 5ms/step - loss: 27964690432.0000 - val_loss: 27940360192.0000
    Epoch 389/400
    119/119 [==============================] - 1s 6ms/step - loss: 27920807936.0000 - val_loss: 27920035840.0000
    Epoch 390/400
    119/119 [==============================] - 1s 5ms/step - loss: 27883759616.0000 - val_loss: 27962511360.0000
    Epoch 391/400
    119/119 [==============================] - 1s 4ms/step - loss: 27867850752.0000 - val_loss: 27913738240.0000
    Epoch 392/400
    119/119 [==============================] - 1s 9ms/step - loss: 27867127808.0000 - val_loss: 27866071040.0000
    Epoch 393/400
    119/119 [==============================] - 1s 6ms/step - loss: 27832891392.0000 - val_loss: 27831781376.0000
    Epoch 394/400
    119/119 [==============================] - 1s 5ms/step - loss: 27853713408.0000 - val_loss: 27836076032.0000
    Epoch 395/400
    119/119 [==============================] - 1s 4ms/step - loss: 27799924736.0000 - val_loss: 27805388800.0000
    Epoch 396/400
    119/119 [==============================] - 1s 5ms/step - loss: 27767470080.0000 - val_loss: 27890542592.0000
    Epoch 397/400
    119/119 [==============================] - 1s 6ms/step - loss: 27768756224.0000 - val_loss: 27798321152.0000
    Epoch 398/400
    119/119 [==============================] - 1s 5ms/step - loss: 27710347264.0000 - val_loss: 27875430400.0000
    Epoch 399/400
    119/119 [==============================] - 0s 4ms/step - loss: 27757221888.0000 - val_loss: 27784308736.0000
    Epoch 400/400
    119/119 [==============================] - 1s 4ms/step - loss: 27741730816.0000 - val_loss: 27768977408.0000
    




    <keras.callbacks.History at 0x232b0463430>



**Explorer l'evaluation sur les données de test et aussi utiliser ce model pour predire un prix à partir de toutes nouvelles données**

On va explorer à quoi ressemble l'historique de perte de notre modéle. loss est notre perte sur le modéle et val_loss est notre perte sur nos données de validation 


```python
losses=pd.DataFrame(Model.history.history)
```

On peut directement comparer le comportement de notre perte d'entrainement donc ici en bleue versus la perte de validation en orange. C'est exactement, le genre de signal que l'on veut avec une décroissance à la fois pour la perte de l'entrainement et pour la perte du test. Et ensuite, il n'y a pas d'augmentation de la perte du set de validaton, cela signifie que techniquement on aurait pu continuer à entrainer. Si on voit cette ligne orange faire un pic après quelques epochs et continuer à augmenter. Cela signifie que nous sommes en overfiting ou surapprentissage de données d'entrainement. Et c'est caracterisé par une bien plus grande perte sur notre ensemble de validation ou test. Dans notre cas, c'est le comportement parfait que nous avons envie de voir. Nous voulons voir la perte d'entrainement et de validation diminuer et continuer cette décroissance ensemble indiquant alors aucun overfiting ici.  


```python
losses.plot()
```




    <AxesSubplot:>




    
![png](output_81_1.png)
    


**Faisons quelques évaluations sur notre set de test** 


```python
from sklearn.metrics import mean_squared_error, mean_absolute_error, explained_variance_score
```


```python
predictions=Model.predict(X_test)
```

    203/203 [==============================] - 1s 3ms/step
    


```python
predictions
```




    array([[ 487763.03],
           [ 632247.4 ],
           [ 544494.75],
           ...,
           [ 406503.78],
           [ 215600.77],
           [1010892.6 ]], dtype=float32)



**On va comparer ces predictions aux valeurs de prix réels** 

Voici notre erreur quadratique moyenne. 


```python
mean_squared_error(y_test, predictions)
```




    27768978079.332733



C'est une trés grande valeur mais ce n'est pas inquietant parce qu'on traite le prix d'une maison. C'est delicat à intrepréter comme valeur puisque l'unité est du dollar au carré, on peut donc prendre la racine carrée de cela. 


```python
np.sqrt(mean_squared_error(y_test, predictions))
```




    166640.2654802636



Regardons l'erreur absolue moyenne. Cette erreur est facile à interpréter parce que c'est la moyenne des erreurs à travers toutes les prédictions. Donc, il semble qu'en moyenne on a un écart à peu près 100000 dollors. Est ce que c'est un bon résultat ou mauvais donc pour y répondre on doit prendre la dataframe réelle. On prend la colonne price et on appelle describe dessus. On voit ainsi une moyenne de 5400000 dollors. Dans notre cas, l'erreur absolue moyenne est de 100000 dollars. Donc, finalement notre modéle n'est pas si bon que ça. On a un écart de 20%. Pas génial pas horible non plus. 


```python
mean_absolute_error(y_test, predictions)
```




    103227.94875968731




```python
df["price"].describe()
```




    count    2.161300e+04
    mean     5.400881e+05
    std      3.671272e+05
    min      7.500000e+04
    25%      3.219500e+05
    50%      4.500000e+05
    75%      6.450000e+05
    max      7.700000e+06
    Name: price, dtype: float64



On peut aussi utiliser le score de variance pour éssayer d'obtenir une compréhension plus en profondeur de nos mesures d'évaluation. Cela indique combien de variance est expliquée par notre modéle. On obtient une valeur de 0.79. Donc, c'est suffisant on peut se contenter de ce modéle. Mais encore une fois cela dépend du contexte et lors de l'entrainement notre perte etait encore entrain de baisser lentement et doucement mais diminuer quand même. On peut aussi comparer nos vlaurs réelles et prédites en les traçant sur un graphique et ajouter la droite de régression parfaite dans le cas nos prédictions sont parfaites


```python
explained_variance_score(y_test, predictions)
```




    0.8021766985473168



Cette ligne rouge répresente la prédiction parfaite. On remarque notre modéle est puni par quelques valeurs abérantes qui sont finalement de prix extrêmes de maisons assez chères. Et on n'est pas bon pour prédire ces maisons qui valent plusieurs millions de dollars. Par contre, on est plutot bon, du moins pas mauvais pour prédire des maisons dont le prix se situent entre 0 et 2 millions de dollars. On constate une bonne correspondance entre nos données test et nos prédictions sur cette portion du graphique entre 0 et 2 millions. Et c'est essentiellemet cette information que la mesure variance score rapporte avec le nombre ou valeur 0.80. Cela pourrait valoir le coup de réentrainer notre modéle non plus sur le dataframe complet mais sur 99% du datframe en retirant les maisons le plus cheres. Ainsi, on aura tendance à dire en cas d'une maison qui vaut plus de 3 millions, desolé mais notre modéle n'est pas assez bon pour ce genre de maisons. Cela dépend du contexte et à quelle question, vous devez répondre et quel probléme vous essayez de résoudre  


```python
plt.figure(figsize=(12,6))
plt.scatter(y_test, predictions)

plt.plot(y_test, y_test, 'r')
```




    [<matplotlib.lines.Line2D at 0x232b2f77ac0>]




    
![png](output_97_1.png)
    


Comment utiliser notre modéle pour prédire toute une nouvelle maison

Le code suivant donne seulement les caractéristiques d'une maison


```python
single_house=df.drop("price", axis=1).iloc[0]
```

La premiére étape c'est de mettre ces données à la même échelle que les données d'entrainement et de test

C'est un tableau numpy mais le shape est un incorrect, il y a qu'un seul crochet. On va le reshape. On a cette fois-ci bien le double crochets de dimension deux. Alors -1 signifie prend le nombres de lignes possibles pour avoir 19 colonnes par rapport aux nombres de valeurs du tableau. Maintenant qu'il est dans une forme ou dimensuion corrécte, on va le mettre en échelle.


```python
single_house.values.reshape(-1,19)
```




    array([[ 3.00000e+00,  1.00000e+00,  1.18000e+03,  5.65000e+03,
             1.00000e+00,  0.00000e+00,  0.00000e+00,  3.00000e+00,
             7.00000e+00,  1.18000e+03,  0.00000e+00,  1.95500e+03,
             0.00000e+00,  4.75112e+01, -1.22257e+02,  1.34000e+03,
             5.65000e+03,  2.01400e+03,  1.00000e+01]])




```python
single_house=scaler.transform(single_house.values.reshape(-1,19))
```

Maintenant, on a plus qu'à utiliser le modéle et prédire en passant cette nouvelle masion. 

Maintenant, on a notre prédiction de prix auquel nous pourrions mettre la maison sur le marché. Et si on regarde le prix de la premiére ligne du dataframe (df) cela nous montre entre guillemets le vrai prix càd le prix auquel la maison etait réellement vendue. Donc 221000 dollars et le modéle predit un prix de vente de 2940000 dollars. Ce modéle peut être problematique si on essaye de prédire des maisons sur de valeurs extrêmes de prix. Donc, ce qui pourrait être intérressant ici sur ce projet serait de réenitrainer notre modéle en supprimant le top 1% même le top 2% des maisons qui ont le plus de valeurs et voir si on peut réduire notre erreur quadratique myenne


```python
Model.predict(single_house)
```

    1/1 [==============================] - 0s 50ms/step
    




    array([[285587.2]], dtype=float32)




```python

```
